package org.tss.cucumberdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CucumberDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
