# Setup and requirements 
- to run the tests you need to have Chrome Browser installed
- set GITHUB_TEST_USER and GITHUB_TEST_PASS as environment variables:
<img width="762" height="198" alt="image" src="https://github.com/user-attachments/assets/996a9ddf-a1d8-4855-a039-81f23a90f385" />

(!! because the repository name has to be unique, before every test run repository name needs to be changed)
